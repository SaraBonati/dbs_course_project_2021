--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3 (Debian 13.3-1.pgdg100+1)
-- Dumped by pg_dump version 13.2 (Debian 13.2-1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dbs_project;
--
-- Name: dbs_project; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE dbs_project WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE dbs_project OWNER TO postgres;

\connect dbs_project

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: country; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.country (
    name character varying(50) NOT NULL,
    code character varying(3) NOT NULL,
    partofworld character varying(50) NOT NULL
);


ALTER TABLE public.country OWNER TO postgres;

--
-- Name: education; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.education (
    cname character varying(50) NOT NULL,
    year integer NOT NULL,
    share_gdp_primary numeric(14,12),
    share_gdp_secondary numeric(14,12),
    share_gdp_tertiary numeric(14,12),
    share_pop_tertiary numeric(4,2),
    primary_rate numeric(14,11),
    secondary_rate numeric(14,11)
);


ALTER TABLE public.education OWNER TO postgres;

--
-- Name: gdp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gdp (
    cname character varying(50) NOT NULL,
    year integer NOT NULL,
    value numeric(17,2)
);


ALTER TABLE public.gdp OWNER TO postgres;

--
-- Name: health; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.health (
    cname character varying(50) NOT NULL,
    year integer NOT NULL,
    life_exp numeric(6,3),
    share_gdp_health numeric(12,9),
    mental_health_daly numeric(12,9),
    mental_health_share numeric(12,9)
);


ALTER TABLE public.health OWNER TO postgres;

--
-- Name: pollution; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pollution (
    cname character varying(50) NOT NULL,
    year integer NOT NULL,
    co2 numeric(14,3),
    indoor_death_rate numeric(14,9),
    outdoor_death_rate numeric(5,2)
);


ALTER TABLE public.pollution OWNER TO postgres;

--
-- Name: population; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.population (
    cname character varying(50) NOT NULL,
    year integer NOT NULL,
    count bigint,
    growth numeric(11,9),
    share_urban numeric(6,3),
    share_sanitation numeric(8,5)
);


ALTER TABLE public.population OWNER TO postgres;

--
-- Name: security; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.security (
    cname character varying(50) NOT NULL,
    year integer NOT NULL,
    unemployment_rate numeric(10,8),
    avg_annual_working_hours numeric(8,4),
    homicide_rate numeric(10,7),
    hr_score numeric(9,8),
    hr_violations numeric(3,1),
    happiness numeric(10,9),
    trust numeric(8,6)
);


ALTER TABLE public.security OWNER TO postgres;

--
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.country (name, code, partofworld) FROM stdin;
\.
COPY public.country (name, code, partofworld) FROM '$$PATH$$/2977.dat';

--
-- Data for Name: education; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.education (cname, year, share_gdp_primary, share_gdp_secondary, share_gdp_tertiary, share_pop_tertiary, primary_rate, secondary_rate) FROM stdin;
\.
COPY public.education (cname, year, share_gdp_primary, share_gdp_secondary, share_gdp_tertiary, share_pop_tertiary, primary_rate, secondary_rate) FROM '$$PATH$$/2982.dat';

--
-- Data for Name: gdp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gdp (cname, year, value) FROM stdin;
\.
COPY public.gdp (cname, year, value) FROM '$$PATH$$/2979.dat';

--
-- Data for Name: health; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.health (cname, year, life_exp, share_gdp_health, mental_health_daly, mental_health_share) FROM stdin;
\.
COPY public.health (cname, year, life_exp, share_gdp_health, mental_health_daly, mental_health_share) FROM '$$PATH$$/2980.dat';

--
-- Data for Name: pollution; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pollution (cname, year, co2, indoor_death_rate, outdoor_death_rate) FROM stdin;
\.
COPY public.pollution (cname, year, co2, indoor_death_rate, outdoor_death_rate) FROM '$$PATH$$/2981.dat';

--
-- Data for Name: population; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.population (cname, year, count, growth, share_urban, share_sanitation) FROM stdin;
\.
COPY public.population (cname, year, count, growth, share_urban, share_sanitation) FROM '$$PATH$$/2978.dat';

--
-- Data for Name: security; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.security (cname, year, unemployment_rate, avg_annual_working_hours, homicide_rate, hr_score, hr_violations, happiness, trust) FROM stdin;
\.
COPY public.security (cname, year, unemployment_rate, avg_annual_working_hours, homicide_rate, hr_score, hr_violations, happiness, trust) FROM '$$PATH$$/2983.dat';

--
-- Name: country country_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.country
    ADD CONSTRAINT country_code_key UNIQUE (code);


--
-- Name: country country_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.country
    ADD CONSTRAINT country_pkey PRIMARY KEY (name);


--
-- Name: education education_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.education
    ADD CONSTRAINT education_pkey PRIMARY KEY (cname, year);


--
-- Name: gdp gdp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gdp
    ADD CONSTRAINT gdp_pkey PRIMARY KEY (cname, year);


--
-- Name: health health_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health
    ADD CONSTRAINT health_pkey PRIMARY KEY (cname, year);


--
-- Name: pollution pollution_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pollution
    ADD CONSTRAINT pollution_pkey PRIMARY KEY (cname, year);


--
-- Name: population population_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.population
    ADD CONSTRAINT population_pkey PRIMARY KEY (cname, year);


--
-- Name: security security_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security
    ADD CONSTRAINT security_pkey PRIMARY KEY (cname, year);


--
-- Name: education education_cname_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.education
    ADD CONSTRAINT education_cname_fkey FOREIGN KEY (cname) REFERENCES public.country(name);


--
-- Name: gdp gdp_cname_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gdp
    ADD CONSTRAINT gdp_cname_fkey FOREIGN KEY (cname) REFERENCES public.country(name);


--
-- Name: health health_cname_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health
    ADD CONSTRAINT health_cname_fkey FOREIGN KEY (cname) REFERENCES public.country(name);


--
-- Name: pollution pollution_cname_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pollution
    ADD CONSTRAINT pollution_cname_fkey FOREIGN KEY (cname) REFERENCES public.country(name);


--
-- Name: population population_cname_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.population
    ADD CONSTRAINT population_cname_fkey FOREIGN KEY (cname) REFERENCES public.country(name);


--
-- Name: security security_cname_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security
    ADD CONSTRAINT security_cname_fkey FOREIGN KEY (cname) REFERENCES public.country(name);


--
-- PostgreSQL database dump complete
--

